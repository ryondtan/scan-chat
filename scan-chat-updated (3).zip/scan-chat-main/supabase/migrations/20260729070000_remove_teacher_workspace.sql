-- Student-only app: drop the teacher-facing announcements feature entirely.
DROP TABLE IF EXISTS public.school_announcements CASCADE;

-- Existing accounts keep whatever role they had (harmless if unused), but
-- new signups are always 'student' — enforced in application code. If you
-- want to fully retire the 'teacher' value from the enum later, that
-- requires migrating any existing 'teacher' rows to 'student' first:
--   UPDATE public.profiles SET role = 'student' WHERE role = 'teacher';
-- Postgres enums can't drop a value directly, so removing it fully means
-- recreating public.app_role without it — worth doing once you're sure no
-- teacher accounts remain.
