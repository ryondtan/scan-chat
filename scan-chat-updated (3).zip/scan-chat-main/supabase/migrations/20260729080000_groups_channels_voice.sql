-- Discord-style groups ("servers"), with text + voice channels.

CREATE TYPE public.channel_type AS ENUM ('text', 'voice');
CREATE TYPE public.server_member_role AS ENUM ('owner', 'member');

CREATE TABLE public.servers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 60),
  icon_url text,
  invite_code text NOT NULL UNIQUE DEFAULT substr(replace(gen_random_uuid()::text, '-', ''), 1, 8),
  owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.server_members (
  server_id uuid NOT NULL REFERENCES public.servers(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.server_member_role NOT NULL DEFAULT 'member',
  joined_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (server_id, user_id)
);

CREATE TABLE public.channels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  server_id uuid NOT NULL REFERENCES public.servers(id) ON DELETE CASCADE,
  name text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 40),
  type public.channel_type NOT NULL DEFAULT 'text',
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.channel_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  channel_id uuid NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL CHECK (char_length(content) BETWEEN 1 AND 4000),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_channels_server_id ON public.channels(server_id);
CREATE INDEX idx_channel_messages_channel_id ON public.channel_messages(channel_id, created_at);
CREATE INDEX idx_server_members_user_id ON public.server_members(user_id);

ALTER TABLE public.servers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.server_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channel_messages ENABLE ROW LEVEL SECURITY;

-- Helper: is the current user a member of this server?
CREATE OR REPLACE FUNCTION public.is_server_member(_server_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.server_members
    WHERE server_id = _server_id AND user_id = _user_id
  );
$$;

CREATE OR REPLACE FUNCTION public.is_server_owner(_server_id uuid, _user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.servers
    WHERE id = _server_id AND owner_id = _user_id
  );
$$;

-- servers
CREATE POLICY "members can view their servers" ON public.servers FOR SELECT TO authenticated
  USING (public.is_server_member(id, auth.uid()));
CREATE POLICY "any user can create a server" ON public.servers FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid());
CREATE POLICY "owner can update server" ON public.servers FOR UPDATE TO authenticated
  USING (owner_id = auth.uid());
CREATE POLICY "owner can delete server" ON public.servers FOR DELETE TO authenticated
  USING (owner_id = auth.uid());

-- server_members
CREATE POLICY "members can view membership of their servers" ON public.server_members FOR SELECT TO authenticated
  USING (public.is_server_member(server_id, auth.uid()));
CREATE POLICY "users can join a server (self only)" ON public.server_members FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "users can leave a server (self only)" ON public.server_members FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR public.is_server_owner(server_id, auth.uid()));

-- channels
CREATE POLICY "members can view channels" ON public.channels FOR SELECT TO authenticated
  USING (public.is_server_member(server_id, auth.uid()));
CREATE POLICY "owner can create channels" ON public.channels FOR INSERT TO authenticated
  WITH CHECK (public.is_server_owner(server_id, auth.uid()));
CREATE POLICY "owner can update channels" ON public.channels FOR UPDATE TO authenticated
  USING (public.is_server_owner(server_id, auth.uid()));
CREATE POLICY "owner can delete channels" ON public.channels FOR DELETE TO authenticated
  USING (public.is_server_owner(server_id, auth.uid()));

-- channel_messages
CREATE POLICY "members can view messages" ON public.channel_messages FOR SELECT TO authenticated
  USING (public.is_server_member((SELECT server_id FROM public.channels WHERE id = channel_id), auth.uid()));
CREATE POLICY "members can send messages" ON public.channel_messages FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND public.is_server_member((SELECT server_id FROM public.channels WHERE id = channel_id), auth.uid())
  );
CREATE POLICY "authors can delete own messages" ON public.channel_messages FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- Auto-join the creator as owner + seed default channels.
CREATE OR REPLACE FUNCTION public.handle_new_server()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.server_members (server_id, user_id, role) VALUES (NEW.id, NEW.owner_id, 'owner');
  INSERT INTO public.channels (server_id, name, type, position) VALUES
    (NEW.id, 'general', 'text', 0),
    (NEW.id, 'General', 'voice', 1);
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS on_server_created ON public.servers;
CREATE TRIGGER on_server_created
  AFTER INSERT ON public.servers
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_server();

ALTER PUBLICATION supabase_realtime ADD TABLE public.channel_messages;
