-- Extend profiles with Google identity + last login tracking
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS google_id text,
  ADD COLUMN IF NOT EXISTS last_login_at timestamptz;

-- handle_new_user: also capture avatar picture + google id on first insert
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_username TEXT;
  v_display TEXT;
  v_role public.app_role;
  v_avatar TEXT;
  v_google_id TEXT;
BEGIN
  v_username := lower(coalesce(
    NEW.raw_user_meta_data->>'username',
    regexp_replace(split_part(coalesce(NEW.email, ''), '@', 1), '[^a-z0-9_]', '', 'g'),
    'user_' || substr(replace(NEW.id::text, '-', ''), 1, 10)
  ));
  IF length(v_username) < 3 THEN
    v_username := 'user_' || substr(replace(NEW.id::text, '-', ''), 1, 10);
  END IF;
  WHILE EXISTS (SELECT 1 FROM public.profiles WHERE username = v_username) LOOP
    v_username := v_username || substr(replace(NEW.id::text, '-', ''), 1, 4);
  END LOOP;

  v_display := coalesce(
    NEW.raw_user_meta_data->>'display_name',
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'name',
    v_username
  );

  -- Google's OAuth payload uses "picture"; some flows use "avatar_url" directly.
  v_avatar := coalesce(NEW.raw_user_meta_data->>'avatar_url', NEW.raw_user_meta_data->>'picture');

  -- Google's OAuth payload identifies the account via "sub" (or "provider_id" in some flows).
  v_google_id := CASE
    WHEN NEW.raw_app_meta_data->>'provider' = 'google'
      THEN coalesce(NEW.raw_user_meta_data->>'provider_id', NEW.raw_user_meta_data->>'sub')
    ELSE NULL
  END;

  v_role := coalesce((NEW.raw_user_meta_data->>'role')::public.app_role, 'student');

  INSERT INTO public.profiles (id, username, display_name, avatar_url, email, role, google_id, last_login_at)
  VALUES (NEW.id, v_username, v_display, v_avatar, NEW.email, v_role, v_google_id, now())
  ON CONFLICT (id) DO UPDATE SET
    avatar_url = COALESCE(EXCLUDED.avatar_url, public.profiles.avatar_url),
    google_id = COALESCE(EXCLUDED.google_id, public.profiles.google_id),
    last_login_at = now();

  RETURN NEW;
END; $$;

-- Keep last_login_at (and refreshed name/picture) current on every sign-in,
-- not just the first one. Supabase bumps auth.users.last_sign_in_at on each login.
CREATE OR REPLACE FUNCTION public.handle_user_login()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.profiles
  SET
    last_login_at = NEW.last_sign_in_at,
    avatar_url = COALESCE(NEW.raw_user_meta_data->>'avatar_url', NEW.raw_user_meta_data->>'picture', public.profiles.avatar_url),
    display_name = COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', public.profiles.display_name),
    google_id = COALESCE(
      CASE WHEN NEW.raw_app_meta_data->>'provider' = 'google'
        THEN coalesce(NEW.raw_user_meta_data->>'provider_id', NEW.raw_user_meta_data->>'sub')
        ELSE NULL END,
      public.profiles.google_id
    )
  WHERE id = NEW.id;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS on_auth_user_login ON auth.users;
CREATE TRIGGER on_auth_user_login
  AFTER UPDATE OF last_sign_in_at ON auth.users
  FOR EACH ROW
  WHEN (NEW.last_sign_in_at IS DISTINCT FROM OLD.last_sign_in_at)
  EXECUTE FUNCTION public.handle_user_login();

REVOKE EXECUTE ON FUNCTION public.handle_user_login() FROM PUBLIC, anon, authenticated;
