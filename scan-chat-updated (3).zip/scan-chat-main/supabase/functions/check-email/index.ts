// Supabase Edge Function: check-email
//
// Given an email address, checks that its domain has valid mail (MX) records.
// This catches typo'd/nonexistent domains (e.g. "user@gmial.con") without
// needing a paid email-verification API. It does NOT confirm the specific
// mailbox exists — only that the domain can receive mail.
//
// Deploy with: supabase functions deploy check-email

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// A short list of common disposable/temp-mail domains. Not exhaustive —
// just enough to catch the most common throwaway-address cases.
const DISPOSABLE_DOMAINS = new Set([
  "mailinator.com",
  "10minutemail.com",
  "guerrillamail.com",
  "tempmail.com",
  "temp-mail.org",
  "yopmail.com",
  "trashmail.com",
]);

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email } = await req.json();

    if (typeof email !== "string" || !EMAIL_REGEX.test(email.trim())) {
      return json({ valid: false, reason: "That email address doesn't look right" });
    }

    const domain = email.trim().split("@")[1].toLowerCase();

    if (DISPOSABLE_DOMAINS.has(domain)) {
      return json({ valid: false, reason: "Please use a permanent email address" });
    }

    const hasMx = await domainHasMailServer(domain);
    if (!hasMx) {
      return json({ valid: false, reason: "This email domain can't receive mail" });
    }

    return json({ valid: true });
  } catch (err) {
    console.error("check-email error:", err);
    // On unexpected errors, don't block the user — fail open.
    return json({ valid: true });
  }
});

async function domainHasMailServer(domain: string): Promise<boolean> {
  try {
    const res = await fetch(
      `https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=MX`,
    );
    if (!res.ok) return true; // DNS lookup failed for reasons unrelated to the domain
    const data = await res.json();
    if (Array.isArray(data.Answer) && data.Answer.length > 0) return true;
    // Some domains (rare) accept mail via an A record instead of MX.
    const aRes = await fetch(
      `https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=A`,
    );
    if (!aRes.ok) return true;
    const aData = await aRes.json();
    return Array.isArray(aData.Answer) && aData.Answer.length > 0;
  } catch {
    return true; // fail open on network errors
  }
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
