import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// ---------- SERVERS (groups) ----------
export const listServers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("server_members")
      .select("role, server:servers(id, name, icon_url, invite_code, owner_id)")
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createServer = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => {
    const d = raw as { name?: string };
    if (!d?.name?.trim()) throw new Error("Server name is required");
    return { name: d.name.trim().slice(0, 60) };
  })
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("servers")
      .insert({ name: data.name, owner_id: context.userId })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

export const joinServerByInviteCode = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => {
    const d = raw as { inviteCode?: string };
    if (!d?.inviteCode?.trim()) throw new Error("Invite code is required");
    return { inviteCode: d.inviteCode.trim() };
  })
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }) => {
    const { data: server, error: findError } = await context.supabase
      .from("servers")
      .select("id, name")
      .eq("invite_code", data.inviteCode)
      .single();
    if (findError || !server) throw new Error("Invalid invite code");

    const { error: joinError } = await context.supabase
      .from("server_members")
      .insert({ server_id: server.id, user_id: context.userId });
    if (joinError && !joinError.message.includes("duplicate")) throw new Error(joinError.message);
    return server;
  });

export const leaveServer = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => {
    const d = raw as { serverId?: string };
    if (!d?.serverId) throw new Error("serverId required");
    return { serverId: d.serverId };
  })
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("server_members")
      .delete()
      .eq("server_id", data.serverId)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------- CHANNELS ----------
export const getServerDetail = createServerFn({ method: "GET" })
  .inputValidator((raw: unknown) => {
    const d = raw as { serverId?: string };
    if (!d?.serverId) throw new Error("serverId required");
    return { serverId: d.serverId };
  })
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }) => {
    const [server, channels, members] = await Promise.all([
      context.supabase.from("servers").select("*").eq("id", data.serverId).single(),
      context.supabase.from("channels").select("*").eq("server_id", data.serverId).order("position"),
      context.supabase
        .from("server_members")
        .select("user_id, role, profile:profiles(username, display_name, avatar_url)")
        .eq("server_id", data.serverId),
    ]);
    if (server.error) throw new Error(server.error.message);
    return {
      server: server.data,
      channels: channels.data ?? [],
      members: members.data ?? [],
      isOwner: server.data.owner_id === context.userId,
    };
  });

export const createChannel = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => {
    const d = raw as { serverId?: string; name?: string; type?: "text" | "voice" };
    if (!d?.serverId || !d?.name?.trim()) throw new Error("serverId and name are required");
    return {
      serverId: d.serverId,
      name: d.name.trim().slice(0, 40),
      type: d.type === "voice" ? "voice" as const : "text" as const,
    };
  })
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("channels")
      .insert({ server_id: data.serverId, name: data.name, type: data.type })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

// ---------- MESSAGES ----------
export const listChannelMessages = createServerFn({ method: "GET" })
  .inputValidator((raw: unknown) => {
    const d = raw as { channelId?: string };
    if (!d?.channelId) throw new Error("channelId required");
    return { channelId: d.channelId };
  })
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }) => {
    const { data: rows, error } = await context.supabase
      .from("channel_messages")
      .select("*, author:profiles!channel_messages_user_id_fkey(username, display_name, avatar_url)")
      .eq("channel_id", data.channelId)
      .order("created_at", { ascending: true })
      .limit(200);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const sendChannelMessage = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => {
    const d = raw as { channelId?: string; content?: string };
    if (!d?.channelId || !d?.content?.trim()) throw new Error("channelId and content are required");
    return { channelId: d.channelId, content: d.content.trim().slice(0, 4000) };
  })
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("channel_messages")
      .insert({ channel_id: data.channelId, user_id: context.userId, content: data.content })
      .select()
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

// ---------- VOICE (LiveKit token) ----------
export const getVoiceToken = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => {
    const d = raw as { channelId?: string };
    if (!d?.channelId) throw new Error("channelId required");
    return { channelId: d.channelId };
  })
  .middleware([requireSupabaseAuth])
  .handler(async ({ data, context }) => {
    // Delegates to the livekit-token edge function so the LiveKit API
    // secret only ever lives in Supabase's function environment, never here.
    const { data: result, error } = await context.supabase.functions.invoke("livekit-token", {
      body: { channelId: data.channelId },
    });
    if (error) throw new Error(error.message);
    return result as { token: string; url: string };
  });
