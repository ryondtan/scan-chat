// Basic RFC-5322-ish email format check. Good enough to catch typos/garbage
// before we bother hitting the network for a domain/MX check.
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export function isEmailFormatValid(email: string): boolean {
  return EMAIL_REGEX.test(email.trim());
}

export type EmailCheckResult = {
  valid: boolean;
  reason?: string;
};

/**
 * Format check + (best-effort) domain check via the check-email edge function,
 * which looks up MX records for the domain. Network failures are treated as
 * "can't tell" rather than "invalid" so a flaky connection never blocks signup.
 */
export async function validateEmail(
  email: string,
  checkDomain: (email: string) => Promise<EmailCheckResult>,
): Promise<EmailCheckResult> {
  const trimmed = email.trim();
  if (!isEmailFormatValid(trimmed)) {
    return { valid: false, reason: "That email address doesn't look right" };
  }
  try {
    return await checkDomain(trimmed);
  } catch {
    // Network/edge-function hiccup — don't block the user over it.
    return { valid: true };
  }
}
