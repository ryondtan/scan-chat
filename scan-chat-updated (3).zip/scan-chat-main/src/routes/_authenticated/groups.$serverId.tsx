import { createFileRoute, useParams } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { VoiceRoom } from "@/components/voice/voice-room";
import {
  getServerDetail,
  createChannel,
  listChannelMessages,
  sendChannelMessage,
} from "@/lib/groups.functions";
import { Hash, Mic, Plus, Send, Copy } from "lucide-react";

export const Route = createFileRoute("/_authenticated/groups/$serverId")({
  ssr: false,
  head: () => ({
    meta: [{ title: "Group — Lumen" }],
  }),
  component: ServerPage,
});

type Channel = { id: string; name: string; type: "text" | "voice"; server_id: string };
type Detail = {
  server: { id: string; name: string; invite_code: string };
  channels: Channel[];
  members: unknown[];
  isOwner: boolean;
};
type Message = {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  author?: { display_name?: string | null; username?: string | null } | null;
};

function ServerPage() {
  const { serverId } = useParams({ from: "/_authenticated/groups/$serverId" });
  const detailFn = useServerFn(getServerDetail);
  const createChannelFn = useServerFn(createChannel);
  const qc = useQueryClient();

  const [activeChannel, setActiveChannel] = useState<Channel | null>(null);
  const [showNewChannel, setShowNewChannel] = useState(false);
  const [newChannelName, setNewChannelName] = useState("");
  const [newChannelType, setNewChannelType] = useState<"text" | "voice">("text");

  const { data } = useQuery({
    queryKey: ["server-detail", serverId],
    queryFn: () => detailFn({ data: { serverId } }) as Promise<Detail>,
  });

  useEffect(() => {
    if (data && !activeChannel && data.channels.length > 0) {
      setActiveChannel(data.channels.find((c) => c.type === "text") ?? data.channels[0]);
    }
  }, [data, activeChannel]);

  const submitNewChannel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChannelName.trim()) return;
    try {
      await createChannelFn({ data: { serverId, name: newChannelName, type: newChannelType } });
      setNewChannelName("");
      setShowNewChannel(false);
      qc.invalidateQueries({ queryKey: ["server-detail", serverId] });
      toast.success("Channel created");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't create channel");
    }
  };

  const copyInvite = () => {
    if (!data) return;
    navigator.clipboard.writeText(data.server.invite_code);
    toast.success("Invite code copied");
  };

  if (!data) {
    return <div className="h-full grid place-items-center text-muted-foreground text-sm">Loading…</div>;
  }

  const textChannels = data.channels.filter((c) => c.type === "text");
  const voiceChannels = data.channels.filter((c) => c.type === "voice");

  return (
    <div className="flex h-screen">
      {/* Channel sidebar */}
      <aside className="w-56 shrink-0 border-r bg-card/40 flex flex-col">
        <div className="px-3 py-3 border-b flex items-center justify-between">
          <h2 className="font-semibold text-sm truncate">{data.server.name}</h2>
          <button onClick={copyInvite} title="Copy invite code" className="text-muted-foreground hover:text-foreground shrink-0">
            <Copy className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-4">
          <div>
            <div className="px-2 text-[11px] font-medium text-muted-foreground uppercase tracking-wide mb-1">Text channels</div>
            {textChannels.map((c) => (
              <button
                key={c.id}
                onClick={() => setActiveChannel(c)}
                className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-sm truncate ${
                  activeChannel?.id === c.id ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:bg-accent/50"
                }`}
              >
                <Hash className="w-3.5 h-3.5 shrink-0" /> {c.name}
              </button>
            ))}
          </div>

          <div>
            <div className="px-2 text-[11px] font-medium text-muted-foreground uppercase tracking-wide mb-1">Voice channels</div>
            {voiceChannels.map((c) => (
              <button
                key={c.id}
                onClick={() => setActiveChannel(c)}
                className={`w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-sm truncate ${
                  activeChannel?.id === c.id ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:bg-accent/50"
                }`}
              >
                <Mic className="w-3.5 h-3.5 shrink-0" /> {c.name}
              </button>
            ))}
          </div>

          {data.isOwner && (
            <button
              onClick={() => setShowNewChannel((s) => !s)}
              className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-sm text-muted-foreground hover:bg-accent/50"
            >
              <Plus className="w-3.5 h-3.5" /> Add channel
            </button>
          )}

          {showNewChannel && (
            <form onSubmit={submitNewChannel} className="p-2 rounded-lg border bg-card space-y-2">
              <input
                autoFocus
                required
                value={newChannelName}
                onChange={(e) => setNewChannelName(e.target.value)}
                placeholder="channel-name"
                className="w-full px-2 py-1.5 rounded-md bg-input border-0 text-xs"
              />
              <div className="flex gap-1">
                {(["text", "voice"] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setNewChannelType(t)}
                    className={`flex-1 py-1 rounded-md text-xs border ${newChannelType === t ? "bg-primary text-primary-foreground border-primary" : "text-muted-foreground"}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
              <button type="submit" className="w-full py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-medium">
                Create
              </button>
            </form>
          )}
        </div>
      </aside>

      {/* Main panel */}
      <div className="flex-1 min-w-0">
        {!activeChannel ? (
          <div className="h-full grid place-items-center text-muted-foreground text-sm">Select a channel</div>
        ) : activeChannel.type === "voice" ? (
          <VoiceRoom
            key={activeChannel.id}
            channelId={activeChannel.id}
            channelName={activeChannel.name}
            onLeave={() => {}}
          />
        ) : (
          <TextChannel key={activeChannel.id} channelId={activeChannel.id} channelName={activeChannel.name} />
        )}
      </div>
    </div>
  );
}

function TextChannel({ channelId, channelName }: { channelId: string; channelName: string }) {
  const listFn = useServerFn(listChannelMessages);
  const sendFn = useServerFn(sendChannelMessage);
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState("");
  const [me, setMe] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setMe(data.user?.id ?? null));
  }, []);

  useEffect(() => {
    let cancel = false;
    listFn({ data: { channelId } }).then((m) => {
      if (!cancel) setMessages(m as Message[]);
    });
    return () => {
      cancel = true;
    };
  }, [channelId, listFn]);

  useEffect(() => {
    const ch = supabase
      .channel(`channel-${channelId}-msgs`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "channel_messages", filter: `channel_id=eq.${channelId}` },
        (payload) => {
          const m = payload.new as Message;
          setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [channelId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    const content = text.trim();
    setText("");
    try {
      await sendFn({ data: { channelId, content } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't send message");
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b flex items-center gap-1.5">
        <Hash className="w-4 h-4 text-muted-foreground" />
        <h3 className="font-medium text-sm">{channelName}</h3>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((m) => (
          <div key={m.id} className="flex gap-2">
            <div className="w-7 h-7 rounded-full bg-accent grid place-items-center text-xs font-medium shrink-0">
              {(m.author?.display_name ?? m.author?.username ?? "?").slice(0, 1).toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="flex items-baseline gap-2">
                <span className="text-sm font-medium">
                  {m.user_id === me ? "You" : m.author?.display_name ?? m.author?.username ?? "Student"}
                </span>
                <span className="text-[11px] text-muted-foreground">
                  {new Date(m.created_at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
                </span>
              </div>
              <p className="text-sm whitespace-pre-wrap break-words">{m.content}</p>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={submit} className="flex gap-2 p-3 border-t">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={`Message #${channelName}`}
          className="flex-1 px-3 py-2 rounded-lg bg-input border-0 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        />
        <button
          type="submit"
          disabled={!text.trim()}
          className="h-9 w-9 grid place-items-center rounded-lg bg-primary text-primary-foreground disabled:opacity-40"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
