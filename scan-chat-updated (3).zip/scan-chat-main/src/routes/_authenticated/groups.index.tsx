import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { PageShell, EmptyState } from "@/lib/page-shell";
import { listServers, createServer, joinServerByInviteCode } from "@/lib/groups.functions";
import { Users, Plus, LogIn, Hash } from "lucide-react";

export const Route = createFileRoute("/_authenticated/groups/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Groups — Lumen" },
      { name: "description", content: "Study groups with text and voice channels." },
    ],
  }),
  component: GroupsPage,
});

type ServerRow = {
  role: string;
  server: { id: string; name: string; icon_url: string | null; invite_code: string; owner_id: string };
};

function GroupsPage() {
  const listFn = useServerFn(listServers);
  const createFn = useServerFn(createServer);
  const joinFn = useServerFn(joinServerByInviteCode);
  const qc = useQueryClient();

  const [showCreate, setShowCreate] = useState(false);
  const [showJoin, setShowJoin] = useState(false);
  const [name, setName] = useState("");
  const [inviteCode, setInviteCode] = useState("");
  const [busy, setBusy] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["servers"],
    queryFn: () => listFn() as Promise<ServerRow[]>,
  });

  const submitCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    try {
      await createFn({ data: { name } });
      setName("");
      setShowCreate(false);
      qc.invalidateQueries({ queryKey: ["servers"] });
      toast.success("Group created");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't create group");
    } finally {
      setBusy(false);
    }
  };

  const submitJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteCode.trim()) return;
    setBusy(true);
    try {
      await joinFn({ data: { inviteCode } });
      setInviteCode("");
      setShowJoin(false);
      qc.invalidateQueries({ queryKey: ["servers"] });
      toast.success("Joined!");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Invalid invite code");
    } finally {
      setBusy(false);
    }
  };

  return (
    <PageShell
      title="Groups"
      description="Study groups with text chat and voice channels."
      actions={
        <div className="flex gap-2">
          <button onClick={() => setShowJoin((s) => !s)} className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium hover:bg-accent">
            <LogIn className="w-4 h-4" /> Join
          </button>
          <button onClick={() => setShowCreate((s) => !s)} className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium">
            <Plus className="w-4 h-4" /> New group
          </button>
        </div>
      }
    >
      {showCreate && (
        <form onSubmit={submitCreate} className="rounded-xl border bg-card p-4 mb-4 flex gap-2">
          <input
            autoFocus
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Group name (e.g. AP Bio Study Group)"
            className="flex-1 px-3 py-2 rounded-lg bg-input border-0 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <button disabled={busy} type="submit" className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium disabled:opacity-50">
            Create
          </button>
        </form>
      )}

      {showJoin && (
        <form onSubmit={submitJoin} className="rounded-xl border bg-card p-4 mb-4 flex gap-2">
          <input
            autoFocus
            required
            value={inviteCode}
            onChange={(e) => setInviteCode(e.target.value)}
            placeholder="Invite code"
            className="flex-1 px-3 py-2 rounded-lg bg-input border-0 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <button disabled={busy} type="submit" className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium disabled:opacity-50">
            Join
          </button>
        </form>
      )}

      {isLoading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((i) => <div key={i} className="h-24 rounded-xl border bg-card animate-pulse" />)}
        </div>
      ) : !data || data.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No groups yet"
          description="Create a study group or join one with an invite code to start chatting and hopping into voice."
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {data.map((row) => (
            <Link
              key={row.server.id}
              to="/groups/$serverId"
              params={{ serverId: row.server.id }}
              className="rounded-xl border bg-card p-4 hover:border-primary/40 transition flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-lg bg-accent grid place-items-center shrink-0">
                <Hash className="w-5 h-5 text-accent-foreground" />
              </div>
              <div className="min-w-0">
                <div className="font-medium truncate">{row.server.name}</div>
                <div className="text-xs text-muted-foreground">{row.role === "owner" ? "Owner" : "Member"}</div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </PageShell>
  );
}
