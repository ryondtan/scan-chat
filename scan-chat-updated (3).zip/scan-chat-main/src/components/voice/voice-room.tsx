import { useEffect, useRef, useState, useCallback } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  Room,
  RoomEvent,
  Track,
  type RemoteParticipant,
  type LocalParticipant,
  type RemoteTrack,
  type RemoteTrackPublication,
  ConnectionState,
} from "livekit-client";
import { toast } from "sonner";
import { getVoiceToken } from "@/lib/groups.functions";
import { Mic, MicOff, Video, VideoOff, MonitorUp, MonitorX, PhoneOff, Loader2 } from "lucide-react";

type ParticipantView = {
  identity: string;
  name: string;
  isLocal: boolean;
  isSpeaking: boolean;
  micOn: boolean;
  cameraOn: boolean;
  screenOn: boolean;
};

export function VoiceRoom({
  channelId,
  channelName,
  onLeave,
}: {
  channelId: string;
  channelName: string;
  onLeave: () => void;
}) {
  const getTokenFn = useServerFn(getVoiceToken);
  const roomRef = useRef<Room | null>(null);
  const videoEls = useRef(new Map<string, HTMLDivElement>());

  const [status, setStatus] = useState<"connecting" | "connected" | "error">("connecting");
  const [participants, setParticipants] = useState<Map<string, ParticipantView>>(new Map());
  const [micOn, setMicOn] = useState(true);
  const [cameraOn, setCameraOn] = useState(false);
  const [screenOn, setScreenOn] = useState(false);

  const upsertParticipant = useCallback((p: LocalParticipant | RemoteParticipant, isLocal: boolean) => {
    setParticipants((prev) => {
      const next = new Map(prev);
      next.set(p.identity, {
        identity: p.identity,
        name: p.name || p.identity,
        isLocal,
        isSpeaking: p.isSpeaking,
        micOn: p.isMicrophoneEnabled,
        cameraOn: p.isCameraEnabled,
        screenOn: p.isScreenShareEnabled,
      });
      return next;
    });
  }, []);

  const attachTrack = useCallback((track: RemoteTrack, identity: string) => {
    if (track.kind === Track.Kind.Audio) {
      track.attach(); // audio elements just need to exist in the DOM; browser plays them
      return;
    }
    const container = videoEls.current.get(identity);
    if (!container) return;
    const el = track.attach() as HTMLVideoElement;
    el.className = "w-full h-full object-cover rounded-lg";
    container.innerHTML = "";
    container.appendChild(el);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const room = new Room({ adaptiveStream: true, dynacast: true });
    roomRef.current = room;

    room
      .on(RoomEvent.ParticipantConnected, (p) => upsertParticipant(p, false))
      .on(RoomEvent.ParticipantDisconnected, (p) => {
        setParticipants((prev) => {
          const next = new Map(prev);
          next.delete(p.identity);
          return next;
        });
      })
      .on(RoomEvent.TrackSubscribed, (track: RemoteTrack, _pub: RemoteTrackPublication, p: RemoteParticipant) => {
        attachTrack(track, p.identity);
        upsertParticipant(p, false);
      })
      .on(RoomEvent.TrackUnsubscribed, (track: RemoteTrack) => {
        track.detach().forEach((el) => el.remove());
      })
      .on(RoomEvent.ActiveSpeakersChanged, () => {
        setParticipants((prev) => {
          const next = new Map(prev);
          for (const [id, view] of next) {
            const p = id === room.localParticipant.identity ? room.localParticipant : room.getParticipantByIdentity(id);
            if (p) next.set(id, { ...view, isSpeaking: p.isSpeaking });
          }
          return next;
        });
      })
      .on(RoomEvent.LocalTrackPublished, () => upsertParticipant(room.localParticipant, true))
      .on(RoomEvent.LocalTrackUnpublished, () => upsertParticipant(room.localParticipant, true))
      .on(RoomEvent.ConnectionStateChanged, (state) => {
        if (state === ConnectionState.Disconnected && !cancelled) {
          setStatus("error");
        }
      });

    (async () => {
      try {
        const { token, url } = await getTokenFn({ data: { channelId } });
        if (cancelled) return;
        await room.connect(url, token);
        if (cancelled) {
          room.disconnect();
          return;
        }
        await room.localParticipant.setMicrophoneEnabled(true).catch(() => {
          toast.error("Couldn't access your microphone");
          setMicOn(false);
        });
        upsertParticipant(room.localParticipant, true);
        // Attach any participants/tracks that already existed when we joined.
        room.remoteParticipants.forEach((p) => {
          upsertParticipant(p, false);
          p.trackPublications.forEach((pub) => {
            if (pub.track) attachTrack(pub.track, p.identity);
          });
        });
        setStatus("connected");
      } catch (err) {
        if (cancelled) return;
        console.error(err);
        toast.error(err instanceof Error ? err.message : "Couldn't join voice channel");
        setStatus("error");
      }
    })();

    return () => {
      cancelled = true;
      room.disconnect();
      roomRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channelId]);

  const toggleMic = async () => {
    const room = roomRef.current;
    if (!room) return;
    const next = !micOn;
    await room.localParticipant.setMicrophoneEnabled(next);
    setMicOn(next);
  };

  const toggleCamera = async () => {
    const room = roomRef.current;
    if (!room) return;
    const next = !cameraOn;
    try {
      await room.localParticipant.setCameraEnabled(next);
      setCameraOn(next);
    } catch {
      toast.error("Couldn't access your camera");
    }
  };

  const toggleScreenShare = async () => {
    const room = roomRef.current;
    if (!room) return;
    const next = !screenOn;
    try {
      await room.localParticipant.setScreenShareEnabled(next);
      setScreenOn(next);
    } catch {
      // User likely cancelled the share picker — not an error worth surfacing.
    }
  };

  const leave = () => {
    roomRef.current?.disconnect();
    onLeave();
  };

  const list = Array.from(participants.values());

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-3 border-b">
        <div>
          <h3 className="font-medium">{channelName}</h3>
          <p className="text-xs text-muted-foreground">
            {status === "connecting" ? "Connecting…" : status === "error" ? "Disconnected" : `${list.length} in voice`}
          </p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {status === "connecting" ? (
          <div className="h-full grid place-items-center text-muted-foreground gap-2">
            <Loader2 className="w-6 h-6 animate-spin" />
            <span className="text-sm">Joining {channelName}…</span>
          </div>
        ) : status === "error" ? (
          <div className="h-full grid place-items-center text-center text-sm text-muted-foreground">
            Lost connection to the voice channel.
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((p) => (
              <div key={p.identity} className="relative aspect-video rounded-lg bg-muted overflow-hidden border">
                {(p.cameraOn || p.screenOn) ? (
                  <div
                    ref={(el) => {
                      if (el) videoEls.current.set(p.identity, el);
                      else videoEls.current.delete(p.identity);
                    }}
                    className="w-full h-full"
                  />
                ) : (
                  <div className="w-full h-full grid place-items-center">
                    <div
                      className={`w-14 h-14 rounded-full grid place-items-center text-lg font-semibold bg-primary/15 text-primary ring-2 transition-all ${
                        p.isSpeaking ? "ring-green-500" : "ring-transparent"
                      }`}
                    >
                      {p.name.slice(0, 1).toUpperCase()}
                    </div>
                  </div>
                )}
                <div className="absolute bottom-1.5 left-1.5 flex items-center gap-1 bg-black/60 text-white text-xs px-2 py-0.5 rounded-md">
                  {p.micOn ? <Mic className="w-3 h-3" /> : <MicOff className="w-3 h-3 text-destructive" />}
                  {p.name}
                  {p.isLocal && " (you)"}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center justify-center gap-2 px-4 py-3 border-t">
        <button
          onClick={toggleMic}
          disabled={status !== "connected"}
          className={`p-2.5 rounded-full transition ${micOn ? "bg-muted hover:bg-accent" : "bg-destructive text-destructive-foreground"}`}
          title={micOn ? "Mute" : "Unmute"}
        >
          {micOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
        </button>
        <button
          onClick={toggleCamera}
          disabled={status !== "connected"}
          className={`p-2.5 rounded-full transition ${cameraOn ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-accent"}`}
          title={cameraOn ? "Turn off camera" : "Turn on camera"}
        >
          {cameraOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
        </button>
        <button
          onClick={toggleScreenShare}
          disabled={status !== "connected"}
          className={`p-2.5 rounded-full transition ${screenOn ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-accent"}`}
          title={screenOn ? "Stop sharing" : "Share screen"}
        >
          {screenOn ? <MonitorX className="w-4 h-4" /> : <MonitorUp className="w-4 h-4" />}
        </button>
        <button
          onClick={leave}
          className="p-2.5 rounded-full bg-destructive text-destructive-foreground hover:opacity-90 transition ml-2"
          title="Leave"
        >
          <PhoneOff className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
