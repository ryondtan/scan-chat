// Supabase Edge Function: livekit-token
//
// Mints a short-lived LiveKit access token scoped to a single study group's
// always-on voice room, after verifying the caller is actually a member of
// that group. The LiveKit API secret never leaves this function.
//
// Discord-style: this is one persistent room per group — anyone who's a
// member can join or leave whenever they want, there's no "calling" anyone.
//
// Required secrets (Supabase Dashboard → Edge Functions → Secrets, or
// `supabase secrets set`): LIVEKIT_API_KEY, LIVEKIT_API_SECRET, LIVEKIT_URL
//
// Deploy with: supabase functions deploy livekit-token

import { createClient } from "npm:@supabase/supabase-js@2";
import { AccessToken } from "npm:livekit-server-sdk@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Missing bearer token" }, 401);
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");
    if (!supabaseUrl || !supabaseAnonKey) {
      return json({ error: "Server misconfigured" }, 500);
    }

    // Client scoped to the caller's own JWT — RLS decides what they can see.
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userData, error: userError } = await supabase.auth.getUser();
    if (userError || !userData.user) {
      return json({ error: "Invalid or expired session" }, 401);
    }
    const userId = userData.user.id;

    const { groupId } = await req.json();
    if (typeof groupId !== "string" || !groupId) {
      return json({ error: "groupId is required" }, 400);
    }

    // Authorization check: is the caller actually a member of this study group?
    const { data: membership, error: memberError } = await supabase
      .from("study_group_members")
      .select("user_id")
      .eq("group_id", groupId)
      .eq("user_id", userId)
      .maybeSingle();

    if (memberError || !membership) {
      return json({ error: "You're not a member of this group" }, 403);
    }

    const apiKey = Deno.env.get("LIVEKIT_API_KEY");
    const apiSecret = Deno.env.get("LIVEKIT_API_SECRET");
    const livekitUrl = Deno.env.get("LIVEKIT_URL");
    if (!apiKey || !apiSecret || !livekitUrl) {
      return json({ error: "Voice chat isn't configured yet (missing LiveKit secrets)" }, 500);
    }

    // One identity per user per room — reconnecting replaces the old session
    // instead of creating a ghost participant.
    const { data: profile } = await supabase
      .from("profiles")
      .select("display_name, username")
      .eq("id", userId)
      .single();

    const at = new AccessToken(apiKey, apiSecret, {
      identity: userId,
      name: profile?.display_name ?? profile?.username ?? "Student",
      ttl: "4h",
    });
    at.addGrant({
      room: groupId,
      roomJoin: true,
      canPublish: true,
      canSubscribe: true,
      canPublishData: true,
    });

    const token = await at.toJwt();
    return json({ token, url: livekitUrl });
  } catch (err) {
    console.error("livekit-token error:", err);
    return json({ error: "Something went wrong issuing the voice token" }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
