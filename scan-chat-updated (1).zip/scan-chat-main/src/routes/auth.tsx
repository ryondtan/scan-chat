import { createFileRoute, useNavigate, redirect } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { isEmailFormatValid, validateEmail, type EmailCheckResult } from "@/lib/validation";
import { Sparkles, Check, X, Loader2, MailWarning } from "lucide-react";
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
} from "@/components/ui/input-otp";

const authSearchSchema = z.object({
  // Present when /_authenticated redirected here because the account's
  // email hasn't been verified yet.
  verify: z.string().email().optional().catch(undefined),
});

export const Route = createFileRoute("/auth")({
  ssr: false,
  validateSearch: authSearchSchema,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (data.session) throw redirect({ to: "/dashboard" });
  },
  component: AuthPage,
});

type Mode = "signin" | "signup" | "signup-verify" | "forgot" | "forgot-verify";
type EmailStatus = "idle" | "checking" | "valid" | "invalid";

async function checkEmailDomain(email: string): Promise<EmailCheckResult> {
  const { data, error } = await supabase.functions.invoke("check-email", {
    body: { email },
  });
  if (error) throw error;
  return data as EmailCheckResult;
}

function AuthPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const [mode, setMode] = useState<Mode>(search.verify ? "signup-verify" : "signin");
  const [needsVerificationNotice, setNeedsVerificationNotice] = useState(!!search.verify);
  const [email, setEmail] = useState(search.verify ?? "");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [role, setRole] = useState<"student" | "teacher">("student");
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  // OTP verification (signup + password reset)
  const [otp, setOtp] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [resending, setResending] = useState(false);

  // Live email validation (signup only)
  const [emailStatus, setEmailStatus] = useState<EmailStatus>("idle");
  const [emailError, setEmailError] = useState<string | null>(null);
  const emailCheckToken = useRef(0);

  useEffect(() => {
    document.getElementById("email-input")?.focus();
  }, [mode]);

  useEffect(() => {
    if (!needsVerificationNotice || !search.verify) return;
    supabase.auth.resend({ type: "signup", email: search.verify }).catch(() => {
      // Best-effort — the user can still tap "Resend code" manually.
    });
    // Only do this once, when we first land here via redirect.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Debounced format + domain check while the user types their signup email.
  useEffect(() => {
    if (mode !== "signup") return;
    const trimmed = email.trim();
    if (!trimmed) {
      setEmailStatus("idle");
      setEmailError(null);
      return;
    }
    if (!isEmailFormatValid(trimmed)) {
      setEmailStatus("invalid");
      setEmailError("That email address doesn't look right");
      return;
    }
    setEmailStatus("checking");
    const token = ++emailCheckToken.current;
    const timer = setTimeout(async () => {
      const result = await validateEmail(trimmed, checkEmailDomain);
      if (emailCheckToken.current !== token) return; // stale response
      setEmailStatus(result.valid ? "valid" : "invalid");
      setEmailError(result.valid ? null : result.reason ?? "This email looks invalid");
    }, 500);
    return () => clearTimeout(timer);
  }, [email, mode]);

  const signInWithGoogle = async () => {
    setGoogleLoading(true);
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin,
      });
      if (result.error) throw result.error;
      if (result.redirected) return;
      navigate({ to: "/dashboard" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Google sign-in failed");
    } finally {
      setGoogleLoading(false);
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const uname = username.trim().toLowerCase();
        if (!/^[a-z0-9_]{3,20}$/.test(uname)) {
          toast.error("Username: 3–20 chars, a–z, 0–9, _");
          return;
        }
        if (emailStatus === "invalid") {
          toast.error(emailError ?? "Please enter a valid email address");
          return;
        }
        // If the domain check is still in flight, wait briefly for it rather
        // than letting an obviously-bad address slip through.
        if (emailStatus === "checking") {
          const result = await validateEmail(email, checkEmailDomain);
          if (!result.valid) {
            setEmailStatus("invalid");
            setEmailError(result.reason ?? "Please enter a valid email address");
            toast.error(result.reason ?? "Please enter a valid email address");
            return;
          }
          setEmailStatus("valid");
        }

        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/`,
            data: { username: uname, display_name: displayName.trim() || uname, role },
          },
        });
        if (error) throw error;

        // Supabase deliberately returns no error for an already-registered,
        // already-confirmed email (to avoid leaking which emails exist) — it
        // just comes back with an empty identities array instead.
        if (data.user && data.user.identities?.length === 0) {
          toast.error("This email is already registered. Try signing in instead.");
          setMode("signin");
          return;
        }

        if (data.session) {
          // Email confirmation is disabled on this project — straight in.
          toast.success("Account created!");
          navigate({ to: "/dashboard" });
        } else {
          toast.success("We sent a verification code to your email");
          setMode("signup-verify");
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) {
          if (error.message.toLowerCase().includes("email not confirmed")) {
            toast.error("Please verify your email before signing in");
            setNeedsVerificationNotice(true);
            await supabase.auth.resend({ type: "signup", email }).catch(() => {});
            setMode("signup-verify");
            return;
          }
          throw error;
        }
        navigate({ to: "/dashboard" });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Something went wrong";
      toast.error(
        msg.includes("duplicate")
          ? "Username already taken"
          : msg.toLowerCase().includes("already registered")
            ? "This email is already registered. Try signing in instead."
            : msg.toLowerCase().includes("invalid login")
              ? "Incorrect email or password"
              : msg,
      );
    } finally {
      setLoading(false);
    }
  };

  const submitSignupVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) return;
    setLoading(true);
    try {
      const { error } = await supabase.auth.verifyOtp({
        email,
        token: otp,
        type: "signup",
      });
      if (error) throw error;
      toast.success("Email verified!");
      navigate({ to: "/dashboard" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Invalid or expired code");
    } finally {
      setLoading(false);
    }
  };

  const resendSignupCode = async () => {
    setResending(true);
    try {
      const { error } = await supabase.auth.resend({ type: "signup", email });
      if (error) throw error;
      toast.success("New code sent");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't resend code");
    } finally {
      setResending(false);
    }
  };

  const submitForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      if (error) throw error;
      toast.success("We sent a reset code to your email");
      setMode("forgot-verify");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Couldn't send reset code");
    } finally {
      setLoading(false);
    }
  };

  const submitForgotVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length !== 6) return;
    if (newPassword.length < 6) {
      toast.error("New password must be at least 6 characters");
      return;
    }
    setLoading(true);
    try {
      const { error: verifyError } = await supabase.auth.verifyOtp({
        email,
        token: otp,
        type: "recovery",
      });
      if (verifyError) throw verifyError;

      const { error: updateError } = await supabase.auth.updateUser({ password: newPassword });
      if (updateError) throw updateError;

      toast.success("Password updated!");
      navigate({ to: "/dashboard" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Invalid or expired code");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-b from-accent/40 to-background">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center shadow-lg mb-4">
            <Sparkles className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold">Lumen</h1>
          <p className="text-sm text-muted-foreground mt-1">AI learning for students and teachers</p>
        </div>

        <div className="bg-card rounded-2xl border shadow-sm p-6">
          {(mode === "signin" || mode === "signup") && (
            <>
              <div className="flex gap-1 p-1 bg-muted rounded-lg mb-5">
                {(["signin", "signup"] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMode(m)}
                    className={`flex-1 py-2 text-sm font-medium rounded-md transition ${mode === m ? "bg-card shadow-sm" : "text-muted-foreground"}`}
                  >
                    {m === "signin" ? "Sign in" : "Sign up"}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={signInWithGoogle}
                disabled={googleLoading}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg border bg-card hover:bg-accent text-sm font-medium transition disabled:opacity-50 mb-4"
              >
                <GoogleIcon />
                {googleLoading ? "Opening Google…" : "Continue with Google"}
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="flex-1 h-px bg-border" />
                <span className="text-xs text-muted-foreground">or with email</span>
                <div className="flex-1 h-px bg-border" />
              </div>

              <form onSubmit={submit} className="space-y-3">
                {mode === "signup" && (
                  <>
                    <input
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="username (3-20, a-z, 0-9, _)"
                      className="w-full px-3 py-2.5 rounded-lg bg-input border-0 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                    <input
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="Display name (optional)"
                      className="w-full px-3 py-2.5 rounded-lg bg-input border-0 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                    <div className="flex gap-2">
                      {(["student", "teacher"] as const).map((r) => (
                        <button
                          key={r}
                          type="button"
                          onClick={() => setRole(r)}
                          className={`flex-1 py-2 rounded-lg text-sm font-medium border transition ${role === r ? "bg-primary text-primary-foreground border-primary" : "bg-card text-muted-foreground"}`}
                        >
                          {r === "student" ? "Student" : "Teacher"}
                        </button>
                      ))}
                    </div>
                  </>
                )}

                <div>
                  <div className="relative">
                    <input
                      id="email-input"
                      required
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Email"
                      autoComplete="email"
                      className={`w-full px-3 py-2.5 pr-9 rounded-lg bg-input border-0 text-sm focus:outline-none focus:ring-2 ${
                        mode === "signup" && emailStatus === "invalid"
                          ? "ring-2 ring-destructive"
                          : "focus:ring-ring"
                      }`}
                    />
                    {mode === "signup" && email.trim() && (
                      <span className="absolute right-3 top-1/2 -translate-y-1/2">
                        {emailStatus === "checking" && (
                          <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                        )}
                        {emailStatus === "valid" && <Check className="w-4 h-4 text-green-600" />}
                        {emailStatus === "invalid" && <X className="w-4 h-4 text-destructive" />}
                      </span>
                    )}
                  </div>
                  {mode === "signup" && emailStatus === "invalid" && emailError && (
                    <p className="text-xs text-destructive mt-1 px-1">{emailError}</p>
                  )}
                </div>

                <input
                  required
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  minLength={6}
                  autoComplete={mode === "signup" ? "new-password" : "current-password"}
                  className="w-full px-3 py-2.5 rounded-lg bg-input border-0 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                />

                {mode === "signin" && (
                  <button
                    type="button"
                    onClick={() => setMode("forgot")}
                    className="text-xs text-muted-foreground hover:text-foreground -mt-1"
                  >
                    Forgot password?
                  </button>
                )}

                <button
                  type="submit"
                  disabled={loading || (mode === "signup" && emailStatus === "invalid")}
                  className="w-full py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 transition"
                >
                  {loading ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}
                </button>
              </form>
            </>
          )}

          {mode === "signup-verify" && (
            <form onSubmit={submitSignupVerify} className="space-y-4">
              {needsVerificationNotice && (
                <div className="flex items-start gap-2 rounded-lg bg-amber-50 text-amber-900 border border-amber-200 px-3 py-2 text-xs">
                  <MailWarning className="w-4 h-4 mt-0.5 shrink-0" />
                  <span>Your email isn't verified yet. Enter the code we just sent to finish signing in.</span>
                </div>
              )}
              <div className="text-center">
                <h2 className="font-semibold">Verify your email</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Enter the 6-digit code we sent to <span className="font-medium">{email}</span>
                </p>
              </div>
              <div className="flex justify-center">
                <InputOTP maxLength={6} value={otp} onChange={setOtp}>
                  <InputOTPGroup>
                    {[0, 1, 2, 3, 4, 5].map((i) => (
                      <InputOTPSlot key={i} index={i} />
                    ))}
                  </InputOTPGroup>
                </InputOTP>
              </div>
              <button
                type="submit"
                disabled={loading || otp.length !== 6}
                className="w-full py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 transition"
              >
                {loading ? "Verifying…" : "Verify"}
              </button>
              <div className="flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setMode("signin");
                    setOtp("");
                    setNeedsVerificationNotice(false);
                  }}
                  className="text-muted-foreground hover:text-foreground"
                >
                  Back to sign in
                </button>
                <button
                  type="button"
                  onClick={resendSignupCode}
                  disabled={resending}
                  className="text-primary hover:underline disabled:opacity-50"
                >
                  {resending ? "Sending…" : "Resend code"}
                </button>
              </div>
            </form>
          )}

          {mode === "forgot" && (
            <form onSubmit={submitForgot} className="space-y-4">
              <div className="text-center">
                <h2 className="font-semibold">Reset your password</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  We'll email you a 6-digit code
                </p>
              </div>
              <input
                id="email-input"
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                autoComplete="email"
                className="w-full px-3 py-2.5 rounded-lg bg-input border-0 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 transition"
              >
                {loading ? "Sending…" : "Send reset code"}
              </button>
              <button
                type="button"
                onClick={() => setMode("signin")}
                className="w-full text-xs text-muted-foreground hover:text-foreground"
              >
                Back to sign in
              </button>
            </form>
          )}

          {mode === "forgot-verify" && (
            <form onSubmit={submitForgotVerify} className="space-y-4">
              <div className="text-center">
                <h2 className="font-semibold">Enter your code</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Sent to <span className="font-medium">{email}</span>
                </p>
              </div>
              <div className="flex justify-center">
                <InputOTP maxLength={6} value={otp} onChange={setOtp}>
                  <InputOTPGroup>
                    {[0, 1, 2, 3, 4, 5].map((i) => (
                      <InputOTPSlot key={i} index={i} />
                    ))}
                  </InputOTPGroup>
                </InputOTP>
              </div>
              <input
                required
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="New password"
                minLength={6}
                autoComplete="new-password"
                className="w-full px-3 py-2.5 rounded-lg bg-input border-0 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
              <button
                type="submit"
                disabled={loading || otp.length !== 6}
                className="w-full py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 transition"
              >
                {loading ? "Updating…" : "Update password"}
              </button>
              <button
                type="button"
                onClick={() => setMode("signin")}
                className="w-full text-xs text-muted-foreground hover:text-foreground"
              >
                Back to sign in
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 48 48" aria-hidden>
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.3-.4-3.5z"/>
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.6 8.4 6.3 14.7z"/>
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35 26.7 36 24 36c-5.3 0-9.7-3.3-11.3-8L6 32.7C9.3 39.4 16.1 44 24 44z"/>
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.3-4.1 5.6l6.2 5.2C39.7 35.9 44 30.6 44 24c0-1.2-.1-2.3-.4-3.5z"/>
    </svg>
  );
}
